<?php

/* security/login.html.twig */
class __TwigTemplate_6ef02fe82fc43f25b1f5de734cb0ff2c629f7877dd453a5470ff1150e9d6bb25 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54e6b93cdf0c68e47e12cf91b1dff82d7fb9c424b74ebb8fe149e5309d508b55 = $this->env->getExtension("native_profiler");
        $__internal_54e6b93cdf0c68e47e12cf91b1dff82d7fb9c424b74ebb8fe149e5309d508b55->enter($__internal_54e6b93cdf0c68e47e12cf91b1dff82d7fb9c424b74ebb8fe149e5309d508b55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        // line 1
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 2
            echo "    <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "</div>
";
        }
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "

<div id=\"container\">
    <form class=\"form-inline\" action=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("recambios_check");
        echo "\" method=\"post\">
        <div class=\"form-group\">

            <label for=\"username\">Usuario:</label>
            <input type=\"text\" class=\"form-control\" id=\"username exampleInputName2\" name=\"_username\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\"
                    placeholder=\"Usuario...\"/>

            <label for=\"password\">Contraseña:</label>
            <input type=\"password\" class=\"form-control\" id=\"password\" name=\"_password\" placeholder=\"PwHnJmQ...\" />

            <input type=\"hidden\" name=\"_target_path\" value=\"account\" />

            <input type=\"submit\" name=\"login\" class=\"btn btn-default\"/>
        </div>
    </form>
</div>

";
        
        $__internal_54e6b93cdf0c68e47e12cf91b1dff82d7fb9c424b74ebb8fe149e5309d508b55->leave($__internal_54e6b93cdf0c68e47e12cf91b1dff82d7fb9c424b74ebb8fe149e5309d508b55_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7e4a58a1165f9583f4cefb62e596842023248496df496d47c50bafa47ad9afa8 = $this->env->getExtension("native_profiler");
        $__internal_7e4a58a1165f9583f4cefb62e596842023248496df496d47c50bafa47ad9afa8->enter($__internal_7e4a58a1165f9583f4cefb62e596842023248496df496d47c50bafa47ad9afa8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/app/css/normalizar.css"), "html", null, true);
        echo "\"
          rel=\"stylesheet\" type=\"text/css\" />
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/app/css/bootstrap.min.css"), "html", null, true);
        echo "\"
          rel=\"stylesheet\" type=\"text/css\" />
    <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/app/css/login.css"), "html", null, true);
        echo "\"
          rel=\"stylesheet\" type=\"text/css\" />
";
        
        $__internal_7e4a58a1165f9583f4cefb62e596842023248496df496d47c50bafa47ad9afa8->leave($__internal_7e4a58a1165f9583f4cefb62e596842023248496df496d47c50bafa47ad9afa8_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 10,  81 => 8,  75 => 6,  69 => 5,  48 => 20,  41 => 16,  36 => 13,  34 => 5,  31 => 4,  25 => 2,  23 => 1,);
    }
}
