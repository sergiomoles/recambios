<?php

/* base.html.twig */
class __TwigTemplate_9b04375ec44a40abd789b740232b73729a774c01bba2f7651df91e3ddff43c70 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76f064c6f5624f69e7d1a2f78e504e3d3e00d81f8cb89e4d314b4aa5096b1721 = $this->env->getExtension("native_profiler");
        $__internal_76f064c6f5624f69e7d1a2f78e504e3d3e00d81f8cb89e4d314b4aa5096b1721->enter($__internal_76f064c6f5624f69e7d1a2f78e504e3d3e00d81f8cb89e4d314b4aa5096b1721_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_76f064c6f5624f69e7d1a2f78e504e3d3e00d81f8cb89e4d314b4aa5096b1721->leave($__internal_76f064c6f5624f69e7d1a2f78e504e3d3e00d81f8cb89e4d314b4aa5096b1721_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_862e5be4dcd8d9535782b382f47a0bb2c30fd627446d21d0a940f850ec39d3e8 = $this->env->getExtension("native_profiler");
        $__internal_862e5be4dcd8d9535782b382f47a0bb2c30fd627446d21d0a940f850ec39d3e8->enter($__internal_862e5be4dcd8d9535782b382f47a0bb2c30fd627446d21d0a940f850ec39d3e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_862e5be4dcd8d9535782b382f47a0bb2c30fd627446d21d0a940f850ec39d3e8->leave($__internal_862e5be4dcd8d9535782b382f47a0bb2c30fd627446d21d0a940f850ec39d3e8_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_384887422f4e9d2e6c536483e00d0ba26a196522c4883468e3c58a79f8c58ad0 = $this->env->getExtension("native_profiler");
        $__internal_384887422f4e9d2e6c536483e00d0ba26a196522c4883468e3c58a79f8c58ad0->enter($__internal_384887422f4e9d2e6c536483e00d0ba26a196522c4883468e3c58a79f8c58ad0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_384887422f4e9d2e6c536483e00d0ba26a196522c4883468e3c58a79f8c58ad0->leave($__internal_384887422f4e9d2e6c536483e00d0ba26a196522c4883468e3c58a79f8c58ad0_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_703e645450f44611967e0db9be8e8c95736c5237d35fee3065df35ff06f0a2a9 = $this->env->getExtension("native_profiler");
        $__internal_703e645450f44611967e0db9be8e8c95736c5237d35fee3065df35ff06f0a2a9->enter($__internal_703e645450f44611967e0db9be8e8c95736c5237d35fee3065df35ff06f0a2a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_703e645450f44611967e0db9be8e8c95736c5237d35fee3065df35ff06f0a2a9->leave($__internal_703e645450f44611967e0db9be8e8c95736c5237d35fee3065df35ff06f0a2a9_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_f1c28aff7d0405be9f5566bf8912b81d0e19fae20e9316bc1f78ab0bf216d73a = $this->env->getExtension("native_profiler");
        $__internal_f1c28aff7d0405be9f5566bf8912b81d0e19fae20e9316bc1f78ab0bf216d73a->enter($__internal_f1c28aff7d0405be9f5566bf8912b81d0e19fae20e9316bc1f78ab0bf216d73a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_f1c28aff7d0405be9f5566bf8912b81d0e19fae20e9316bc1f78ab0bf216d73a->leave($__internal_f1c28aff7d0405be9f5566bf8912b81d0e19fae20e9316bc1f78ab0bf216d73a_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
