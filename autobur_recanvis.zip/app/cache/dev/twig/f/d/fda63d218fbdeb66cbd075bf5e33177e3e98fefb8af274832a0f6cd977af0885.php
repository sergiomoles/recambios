<?php

/* security/portada.html.twig */
class __TwigTemplate_fda63d218fbdeb66cbd075bf5e33177e3e98fefb8af274832a0f6cd977af0885 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8b004bffa43765475e163c6b11ee4f9a0d107a8f905c034053099fbb1a4bcf7 = $this->env->getExtension("native_profiler");
        $__internal_f8b004bffa43765475e163c6b11ee4f9a0d107a8f905c034053099fbb1a4bcf7->enter($__internal_f8b004bffa43765475e163c6b11ee4f9a0d107a8f905c034053099fbb1a4bcf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/portada.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    <title>Portada | Recambios Autobur</title>
</head>
<body id=\"portada\"><div id=\"contenedor\">
    <header>
        <h1><a href=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("recambios_check");
        echo "\">Recambios AUTOBUR</a></h1>
        <nav>
            <ul>
                <li><a href=\"#\">1</a></li>
                <li><a href=\"#\">2</a></li>
                <li><a href=\"#\">3</a></li>
                <li><a href=\"#\">4</a></li>
            </ul> </nav>
    </header>
    <h2>Hola ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : $this->getContext($context, "usuario")), "username", array()), "html", null, true);
        echo ". Bienvenido a la aplicación de recambios de taller.</h2>

    <aside>
        ## FORMULARIO DE LOGIN ##
        <section id=\"nosotros\">
            <h2>Sobre nosotros</h2>
            <p>Lorem ipsum dolor sit amet...</p>
        </section>
    </aside>
    <footer>
        &copy; 2015 - Desenvolupat per enbinari coop.
        <a href=\"#\">Ayuda</a>
        <a href=\"#\">Contacto</a>
        <a href=\"#\">Privacidad</a>
        <a href=\"#\">Sobre nosotros</a>
    </footer>
</div></body>
</html>";
        
        $__internal_f8b004bffa43765475e163c6b11ee4f9a0d107a8f905c034053099fbb1a4bcf7->leave($__internal_f8b004bffa43765475e163c6b11ee4f9a0d107a8f905c034053099fbb1a4bcf7_prof);

    }

    public function getTemplateName()
    {
        return "security/portada.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 18,  32 => 9,  22 => 1,);
    }
}
