<?php

/* security/portada.html.twig */
class __TwigTemplate_154c5dc9451170098178bbaff29b86182b4655d29b19f63f71672da0d71847ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1cc0a48a7723eeefa66c9c16805bb2bb68c6c14aa0d255211b95fb1f864b1cd = $this->env->getExtension("native_profiler");
        $__internal_a1cc0a48a7723eeefa66c9c16805bb2bb68c6c14aa0d255211b95fb1f864b1cd->enter($__internal_a1cc0a48a7723eeefa66c9c16805bb2bb68c6c14aa0d255211b95fb1f864b1cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/portada.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    <title>Portada | Recambios Autobur</title>
    ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "</head>
<body id=\"portada\"><div id=\"contenedor\">
    <header>
        <h1><a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("recambios_check");
        echo "\">Recambios AUTOBUR</a></h1>
        <nav>
            <ul>
                <li><a href=\"#\" class=\"btn btn-primary btn-lg\">Búsqueda</a></li>
                <li><a href=\"#\" class=\"btn btn-primary btn-lg\">Historial</a></li>
                <li><a href=\"#\" class=\"btn btn-primary btn-lg\">Vehiculo</a></li>
            </ul> </nav>
    </header>
    <h2>Bienvenido a la aplicación de recambios de taller.</h2>

    <small>Hola ";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["usuario"]) ? $context["usuario"] : $this->getContext($context, "usuario")), "username", array()), "html", null, true);
        echo ".</small>

    <aside>
        ## FORMULARIO DE LOGIN ##
        <section id=\"nosotros\">
            <h2>Sobre nosotros</h2>
            <p>Lorem ipsum dolor sit amet...</p>
        </section>
    </aside>
    <footer>
        &copy; 2015 - Desenvolupat per enbinari coop.
        <a href=\"#\">Ayuda</a>
        <a href=\"#\">Contacto</a>
        <a href=\"#\">Privacidad</a>
        <a href=\"#\">Sobre nosotros</a>
    </footer>
</div></body>
</html>";
        
        $__internal_a1cc0a48a7723eeefa66c9c16805bb2bb68c6c14aa0d255211b95fb1f864b1cd->leave($__internal_a1cc0a48a7723eeefa66c9c16805bb2bb68c6c14aa0d255211b95fb1f864b1cd_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_89027fe5270f4d9b6ecc00867d41cc30b847c8ce21642415a0dfedaa031f7b80 = $this->env->getExtension("native_profiler");
        $__internal_89027fe5270f4d9b6ecc00867d41cc30b847c8ce21642415a0dfedaa031f7b80->enter($__internal_89027fe5270f4d9b6ecc00867d41cc30b847c8ce21642415a0dfedaa031f7b80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "        <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/app/css/normalizar.css"), "html", null, true);
        echo "\"
              rel=\"stylesheet\" type=\"text/css\" />
        <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/app/css/bootstrap.min.css"), "html", null, true);
        echo "\"
              rel=\"stylesheet\" type=\"text/css\" />
    ";
        
        $__internal_89027fe5270f4d9b6ecc00867d41cc30b847c8ce21642415a0dfedaa031f7b80->leave($__internal_89027fe5270f4d9b6ecc00867d41cc30b847c8ce21642415a0dfedaa031f7b80_prof);

    }

    public function getTemplateName()
    {
        return "security/portada.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 9,  81 => 7,  75 => 6,  50 => 25,  37 => 15,  32 => 12,  30 => 6,  23 => 1,);
    }
}
